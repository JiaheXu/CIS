./main.py "DATA/" 0 "OUTPUT/" --eval True;
./main.py "DATA/" 1 "OUTPUT/" --eval True;
./main.py "DATA/" 2 "OUTPUT/" --eval True;
./main.py "DATA/" 3 "OUTPUT/" --eval True;
./main.py "DATA/" 4 "OUTPUT/" --eval True;
./main.py "DATA/" 5 "OUTPUT/" --eval True;
./main.py "DATA/" 6 "OUTPUT/"
./main.py "DATA/" 7 "OUTPUT/"
./main.py "DATA/" 8 "OUTPUT/"

