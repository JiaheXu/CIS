rm OUTPUT/*;
rm EVAL/*;
